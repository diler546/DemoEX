﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Shuler_FoodDiary.Models;
using System;
using System.Linq;

namespace Shuler_FoodDiaryUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        FoodDiaryDb context = new FoodDiaryDb();

        [TestMethod]
        public void TestMethod1()
        {
            var list = context.ShoppingList.FirstOrDefault(s =>s.IdShoppingList == 9);
            Assert.AreEqual(list.GetAmountItems(), 2);
        }
    }
}
