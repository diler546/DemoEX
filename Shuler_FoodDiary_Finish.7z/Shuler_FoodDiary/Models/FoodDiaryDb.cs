using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Shuler_FoodDiary.Models
{
    public partial class FoodDiaryDb : DbContext
    {
        public FoodDiaryDb()
            : base("name=FoodDiaryDb")
        {
        }

        public virtual DbSet<Location> Location { get; set; }
        public virtual DbSet<Product> Product { get; set; }
        public virtual DbSet<Promo> Promo { get; set; }
        public virtual DbSet<Shop> Shop { get; set; }
        public virtual DbSet<ShopOfLocation> ShopOfLocation { get; set; }
        public virtual DbSet<ShopOfProduct> ShopOfProduct { get; set; }
        public virtual DbSet<ShoppingList> ShoppingList { get; set; }
        public virtual DbSet<ShoppingListOfProduct> ShoppingListOfProduct { get; set; }
        public virtual DbSet<WorkingTime> WorkingTime { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Location>()
                .HasMany(e => e.ShopOfLocation)
                .WithRequired(e => e.Location)
                .HasForeignKey(e => e.LocationId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Product>()
                .HasMany(e => e.ShopOfProduct)
                .WithRequired(e => e.Product)
                .HasForeignKey(e => e.ProductId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Product>()
                .HasMany(e => e.ShoppingListOfProduct)
                .WithRequired(e => e.Product)
                .HasForeignKey(e => e.ProductId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Shop>()
                .HasMany(e => e.Promo)
                .WithRequired(e => e.Shop)
                .HasForeignKey(e => e.ShopId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Shop>()
                .HasMany(e => e.ShopOfLocation)
                .WithRequired(e => e.Shop)
                .HasForeignKey(e => e.ShopId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Shop>()
                .HasMany(e => e.ShopOfProduct)
                .WithRequired(e => e.Shop)
                .HasForeignKey(e => e.ShopId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ShopOfLocation>()
                .HasMany(e => e.ShoppingList)
                .WithRequired(e => e.ShopOfLocation)
                .HasForeignKey(e => e.ShopOfLocationId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ShoppingList>()
                .HasMany(e => e.ShoppingListOfProduct)
                .WithRequired(e => e.ShoppingList)
                .HasForeignKey(e => e.ShoppingListId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<WorkingTime>()
                .HasMany(e => e.Shop)
                .WithOptional(e => e.WorkingTime)
                .HasForeignKey(e => e.WorkingTimeId);
        }
    }
}
