namespace Shuler_FoodDiary.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Shop")]
    public partial class Shop
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Shop()
        {
            Promo = new HashSet<Promo>();
            ShopOfLocation = new HashSet<ShopOfLocation>();
            ShopOfProduct = new HashSet<ShopOfProduct>();
        }

        [Key]
        public int IdShop { get; set; }

        [Required]
        [StringLength(255)]
        public string NameShop { get; set; }

        public int? WorkingTimeId { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Promo> Promo { get; set; }

        public virtual WorkingTime WorkingTime { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShopOfLocation> ShopOfLocation { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShopOfProduct> ShopOfProduct { get; set; }
    }
}
