namespace Shuler_FoodDiary.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("WorkingTime")]
    public partial class WorkingTime
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public WorkingTime()
        {
            Shop = new HashSet<Shop>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdWorkingTime { get; set; }

        public TimeSpan? OpeningWorkWeek { get; set; }

        public TimeSpan? ClosingWorkWeek { get; set; }

        public TimeSpan? OpeningWeekends { get; set; }

        public TimeSpan? ClosingWeekends { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Shop> Shop { get; set; }
    }
}
