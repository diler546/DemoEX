namespace Shuler_FoodDiary.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ShopOfProduct")]
    public partial class ShopOfProduct
    {
        [Key]
        public int IdShopOfProduct { get; set; }

        public int ShopId { get; set; }

        public int ProductId { get; set; }

        public int IsAvailable { get; set; }

        public virtual Product Product { get; set; }

        public virtual Shop Shop { get; set; }
    }
}
