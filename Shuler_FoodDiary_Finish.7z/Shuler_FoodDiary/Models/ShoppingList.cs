namespace Shuler_FoodDiary.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    [Table("ShoppingList")]
    public partial class ShoppingList
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ShoppingList()
        {
            ShoppingListOfProduct = new HashSet<ShoppingListOfProduct>();
        }

        [Key]
        public int IdShoppingList { get; set; }

        public DateTime Date { get; set; }

        public int ShopOfLocationId { get; set; }

        [StringLength(255)]
        public string CommentShoppingList { get; set; }

        public int IsArchive { get; set; }

        public int GetAmountItems()
        {
            var sum = 0;
            return sum += Program.context.ShoppingListOfProduct.Where(s => s.ShoppingListId == IdShoppingList).Count();
        }
        public bool isNew()
        {
            return IdShoppingList == 0;
        }

        public int ItemsCount
        {
            get
            {
                return GetAmountItems();
            }
        }

        public virtual ShopOfLocation ShopOfLocation { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShoppingListOfProduct> ShoppingListOfProduct { get; set; }
    }
}
