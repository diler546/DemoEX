namespace Shuler_FoodDiary.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Promo")]
    public partial class Promo
    {
        [Key]
        public int IdPromo { get; set; }

        public int ShopId { get; set; }

        [Required]
        [StringLength(255)]
        public string NamePromo { get; set; }

        [Required]
        [StringLength(255)]
        public string Description { get; set; }

        public virtual Shop Shop { get; set; }
    }
}
