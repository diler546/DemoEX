namespace Shuler_FoodDiary.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ShopOfLocation")]
    public partial class ShopOfLocation
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ShopOfLocation()
        {
            ShoppingList = new HashSet<ShoppingList>();
        }

        [Key]
        public int IdShopOfLocation { get; set; }

        public int ShopId { get; set; }

        public int LocationId { get; set; }

        public virtual Location Location { get; set; }

        public virtual Shop Shop { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShoppingList> ShoppingList { get; set; }
    }
}
