namespace Shuler_FoodDiary.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ShoppingListOfProduct")]
    public partial class ShoppingListOfProduct
    {
        [Key]
        public int IdShoppingListOfProduct { get; set; }

        public int ShoppingListId { get; set; }

        public int ProductId { get; set; }

        public int Quantity { get; set; }

        [StringLength(255)]
        public string CommentProduct { get; set; }

        public virtual Product Product { get; set; }

        public virtual ShoppingList ShoppingList { get; set; }
    }
}
