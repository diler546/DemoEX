﻿namespace Shuler_FoodDiary.AppForms
{
    partial class ShowUpdateShopingListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dateLabelAttentionFont;
            System.Windows.Forms.Label commentShoppingListLabelAttentionFont;
            System.Windows.Forms.Label shopIdLabelAttentionFont;
            System.Windows.Forms.Label locationIdLabelAttentionFont;
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.locationIdComboBox = new System.Windows.Forms.ComboBox();
            this.shopOfLocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.foodDiaryDataSet = new Shuler_FoodDiary.FoodDiaryDataSet();
            this.locationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shopIdComboBox = new System.Windows.Forms.ComboBox();
            this.shopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.commentShoppingListTextBox = new System.Windows.Forms.TextBox();
            this.shoppingListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.NewProductAttentionBackground = new System.Windows.Forms.Button();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shoppingListOfProductDataGridView = new System.Windows.Forms.DataGridView();
            this.Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductId = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsAvailable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shoppingListOfProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingListOfProductTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShoppingListOfProductTableAdapter();
            this.tableAdapterManager = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.TableAdapterManager();
            this.productTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ProductTableAdapter();
            this.shopOfProductTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShopOfProductTableAdapter();
            this.shopOfProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingListTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShoppingListTableAdapter();
            this.shopOfLocationTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShopOfLocationTableAdapter();
            this.locationTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.LocationTableAdapter();
            this.shopTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShopTableAdapter();
            dateLabelAttentionFont = new System.Windows.Forms.Label();
            commentShoppingListLabelAttentionFont = new System.Windows.Forms.Label();
            shopIdLabelAttentionFont = new System.Windows.Forms.Label();
            locationIdLabelAttentionFont = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shopOfLocationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodDiaryDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListOfProductDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListOfProductBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopOfProductBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dateLabelAttentionFont
            // 
            dateLabelAttentionFont.AutoSize = true;
            dateLabelAttentionFont.Location = new System.Drawing.Point(549, 39);
            dateLabelAttentionFont.Name = "dateLabelAttentionFont";
            dateLabelAttentionFont.Size = new System.Drawing.Size(36, 13);
            dateLabelAttentionFont.TabIndex = 3;
            dateLabelAttentionFont.Text = "Дата:";
            // 
            // commentShoppingListLabelAttentionFont
            // 
            commentShoppingListLabelAttentionFont.AutoSize = true;
            commentShoppingListLabelAttentionFont.Location = new System.Drawing.Point(442, 69);
            commentShoppingListLabelAttentionFont.Name = "commentShoppingListLabelAttentionFont";
            commentShoppingListLabelAttentionFont.Size = new System.Drawing.Size(140, 13);
            commentShoppingListLabelAttentionFont.TabIndex = 5;
            commentShoppingListLabelAttentionFont.Text = "Комментарий для списка:";
            // 
            // shopIdLabelAttentionFont
            // 
            shopIdLabelAttentionFont.AutoSize = true;
            shopIdLabelAttentionFont.Location = new System.Drawing.Point(217, 38);
            shopIdLabelAttentionFont.Name = "shopIdLabelAttentionFont";
            shopIdLabelAttentionFont.Size = new System.Drawing.Size(54, 13);
            shopIdLabelAttentionFont.TabIndex = 7;
            shopIdLabelAttentionFont.Text = "Магазин:";
            shopIdLabelAttentionFont.Click += new System.EventHandler(this.shopIdLabel_Click);
            // 
            // locationIdLabelAttentionFont
            // 
            locationIdLabelAttentionFont.AutoSize = true;
            locationIdLabelAttentionFont.Location = new System.Drawing.Point(217, 69);
            locationIdLabelAttentionFont.Name = "locationIdLabelAttentionFont";
            locationIdLabelAttentionFont.Size = new System.Drawing.Size(54, 13);
            locationIdLabelAttentionFont.TabIndex = 9;
            locationIdLabelAttentionFont.Text = "Локация:";
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.AutoScroll = true;
            this.splitContainer.Panel1.Controls.Add(locationIdLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.locationIdComboBox);
            this.splitContainer.Panel1.Controls.Add(shopIdLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.shopIdComboBox);
            this.splitContainer.Panel1.Controls.Add(commentShoppingListLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.commentShoppingListTextBox);
            this.splitContainer.Panel1.Controls.Add(dateLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.dateDateTimePicker);
            this.splitContainer.Panel1.Controls.Add(this.NewProductAttentionBackground);
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.shoppingListOfProductDataGridView);
            this.splitContainer.Size = new System.Drawing.Size(800, 450);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 1;
            // 
            // locationIdComboBox
            // 
            this.locationIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.shopOfLocationBindingSource, "LocationId", true));
            this.locationIdComboBox.DataSource = this.locationBindingSource;
            this.locationIdComboBox.DisplayMember = "NameLocation";
            this.locationIdComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.locationIdComboBox.FormattingEnabled = true;
            this.locationIdComboBox.Location = new System.Drawing.Point(286, 66);
            this.locationIdComboBox.Name = "locationIdComboBox";
            this.locationIdComboBox.Size = new System.Drawing.Size(121, 21);
            this.locationIdComboBox.TabIndex = 10;
            this.locationIdComboBox.ValueMember = "IdLocation";
            this.locationIdComboBox.SelectedIndexChanged += new System.EventHandler(this.locationIdComboBox_SelectedIndexChanged);
            // 
            // shopOfLocationBindingSource
            // 
            this.shopOfLocationBindingSource.DataMember = "ShopOfLocation";
            this.shopOfLocationBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // foodDiaryDataSet
            // 
            this.foodDiaryDataSet.DataSetName = "FoodDiaryDataSet";
            this.foodDiaryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // locationBindingSource
            // 
            this.locationBindingSource.DataMember = "Location";
            this.locationBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // shopIdComboBox
            // 
            this.shopIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.shopOfLocationBindingSource, "ShopId", true));
            this.shopIdComboBox.DataSource = this.shopBindingSource;
            this.shopIdComboBox.DisplayMember = "NameShop";
            this.shopIdComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.shopIdComboBox.FormattingEnabled = true;
            this.shopIdComboBox.Location = new System.Drawing.Point(286, 35);
            this.shopIdComboBox.Name = "shopIdComboBox";
            this.shopIdComboBox.Size = new System.Drawing.Size(121, 21);
            this.shopIdComboBox.TabIndex = 8;
            this.shopIdComboBox.ValueMember = "IdShop";
            this.shopIdComboBox.SelectedIndexChanged += new System.EventHandler(this.shopIdComboBox_SelectedIndexChanged);
            // 
            // shopBindingSource
            // 
            this.shopBindingSource.DataMember = "Shop";
            this.shopBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // commentShoppingListTextBox
            // 
            this.commentShoppingListTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shoppingListBindingSource, "CommentShoppingList", true));
            this.commentShoppingListTextBox.Location = new System.Drawing.Point(588, 66);
            this.commentShoppingListTextBox.Name = "commentShoppingListTextBox";
            this.commentShoppingListTextBox.Size = new System.Drawing.Size(200, 20);
            this.commentShoppingListTextBox.TabIndex = 6;
            this.commentShoppingListTextBox.Leave += new System.EventHandler(this.commentShoppingListTextBox_Leave);
            // 
            // shoppingListBindingSource
            // 
            this.shoppingListBindingSource.DataMember = "ShoppingList";
            this.shoppingListBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.shoppingListBindingSource, "Date", true));
            this.dateDateTimePicker.Enabled = false;
            this.dateDateTimePicker.Location = new System.Drawing.Point(588, 35);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateDateTimePicker.TabIndex = 4;
            // 
            // NewProductAttentionBackground
            // 
            this.NewProductAttentionBackground.Location = new System.Drawing.Point(89, 46);
            this.NewProductAttentionBackground.Name = "NewProductAttentionBackground";
            this.NewProductAttentionBackground.Size = new System.Drawing.Size(96, 23);
            this.NewProductAttentionBackground.TabIndex = 2;
            this.NewProductAttentionBackground.Text = "Новая запись";
            this.NewProductAttentionBackground.UseVisualStyleBackColor = true;
            this.NewProductAttentionBackground.Click += new System.EventHandler(this.NewProductAttentionBackground_Click);
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(86, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(88, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Список покупок";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Shuler_FoodDiary.Properties.Resources.ООО_Лапша_и_шалости;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // shoppingListOfProductDataGridView
            // 
            this.shoppingListOfProductDataGridView.AllowUserToAddRows = false;
            this.shoppingListOfProductDataGridView.AllowUserToDeleteRows = false;
            this.shoppingListOfProductDataGridView.AutoGenerateColumns = false;
            this.shoppingListOfProductDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.shoppingListOfProductDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.shoppingListOfProductDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Number,
            this.ProductId,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.IsAvailable});
            this.shoppingListOfProductDataGridView.DataSource = this.shoppingListOfProductBindingSource;
            this.shoppingListOfProductDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shoppingListOfProductDataGridView.Location = new System.Drawing.Point(0, 0);
            this.shoppingListOfProductDataGridView.Name = "shoppingListOfProductDataGridView";
            this.shoppingListOfProductDataGridView.Size = new System.Drawing.Size(800, 356);
            this.shoppingListOfProductDataGridView.TabIndex = 0;
            this.shoppingListOfProductDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.shoppingListOfProductDataGridView_CellContentClick);
            this.shoppingListOfProductDataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.shoppingListOfProductDataGridView_CellEndEdit);
            // 
            // Number
            // 
            this.Number.HeaderText = "Номер по порядку";
            this.Number.Name = "Number";
            this.Number.ReadOnly = true;
            // 
            // ProductId
            // 
            this.ProductId.DataPropertyName = "ProductId";
            this.ProductId.DataSource = this.productBindingSource;
            this.ProductId.DisplayMember = "NameProduct";
            this.ProductId.HeaderText = "Продукт";
            this.ProductId.Name = "ProductId";
            this.ProductId.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ProductId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ProductId.ValueMember = "IdProduct";
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn4.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CommentProduct";
            this.dataGridViewTextBoxColumn5.HeaderText = "Коментрарий";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // IsAvailable
            // 
            this.IsAvailable.HeaderText = "Доступен";
            this.IsAvailable.Name = "IsAvailable";
            this.IsAvailable.ReadOnly = true;
            // 
            // shoppingListOfProductBindingSource
            // 
            this.shoppingListOfProductBindingSource.DataMember = "ShoppingListOfProduct";
            this.shoppingListOfProductBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // shoppingListOfProductTableAdapter
            // 
            this.shoppingListOfProductTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LocationTableAdapter = null;
            this.tableAdapterManager.ProductTableAdapter = this.productTableAdapter;
            this.tableAdapterManager.PromoTableAdapter = null;
            this.tableAdapterManager.ShopOfLocationTableAdapter = null;
            this.tableAdapterManager.ShopOfProductTableAdapter = this.shopOfProductTableAdapter;
            this.tableAdapterManager.ShoppingListOfProductTableAdapter = this.shoppingListOfProductTableAdapter;
            this.tableAdapterManager.ShoppingListTableAdapter = null;
            this.tableAdapterManager.ShopTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WorkingTimeTableAdapter = null;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // shopOfProductTableAdapter
            // 
            this.shopOfProductTableAdapter.ClearBeforeFill = true;
            // 
            // shopOfProductBindingSource
            // 
            this.shopOfProductBindingSource.DataMember = "ShopOfProduct";
            this.shopOfProductBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // shoppingListTableAdapter
            // 
            this.shoppingListTableAdapter.ClearBeforeFill = true;
            // 
            // shopOfLocationTableAdapter
            // 
            this.shopOfLocationTableAdapter.ClearBeforeFill = true;
            // 
            // locationTableAdapter
            // 
            this.locationTableAdapter.ClearBeforeFill = true;
            // 
            // shopTableAdapter
            // 
            this.shopTableAdapter.ClearBeforeFill = true;
            // 
            // ShowUpdateShopingListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer);
            this.MinimumSize = new System.Drawing.Size(816, 489);
            this.Name = "ShowUpdateShopingListForm";
            this.Text = "ShowUpdateShopingListForm";
            this.Load += new System.EventHandler(this.ShowUpdateShopingListForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.shopOfLocationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodDiaryDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListOfProductDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListOfProductBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopOfProductBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Button NewProductAttentionBackground;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private FoodDiaryDataSet foodDiaryDataSet;
        private System.Windows.Forms.BindingSource shoppingListOfProductBindingSource;
        private FoodDiaryDataSetTableAdapters.ShoppingListOfProductTableAdapter shoppingListOfProductTableAdapter;
        private FoodDiaryDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView shoppingListOfProductDataGridView;
        private FoodDiaryDataSetTableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.BindingSource productBindingSource;
        private FoodDiaryDataSetTableAdapters.ShopOfProductTableAdapter shopOfProductTableAdapter;
        private System.Windows.Forms.BindingSource shopOfProductBindingSource;
        private System.Windows.Forms.BindingSource shoppingListBindingSource;
        private FoodDiaryDataSetTableAdapters.ShoppingListTableAdapter shoppingListTableAdapter;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.TextBox commentShoppingListTextBox;
        private System.Windows.Forms.BindingSource shopOfLocationBindingSource;
        private FoodDiaryDataSetTableAdapters.ShopOfLocationTableAdapter shopOfLocationTableAdapter;
        private System.Windows.Forms.ComboBox locationIdComboBox;
        private System.Windows.Forms.ComboBox shopIdComboBox;
        private System.Windows.Forms.BindingSource locationBindingSource;
        private FoodDiaryDataSetTableAdapters.LocationTableAdapter locationTableAdapter;
        private System.Windows.Forms.BindingSource shopBindingSource;
        private FoodDiaryDataSetTableAdapters.ShopTableAdapter shopTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Number;
        private System.Windows.Forms.DataGridViewComboBoxColumn ProductId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn IsAvailable;
    }
}