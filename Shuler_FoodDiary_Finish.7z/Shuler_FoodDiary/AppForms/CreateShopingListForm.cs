﻿using Shuler_FoodDiary.CustomControls;
using Shuler_FoodDiary.Models;
using Shuler_FoodDiary.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shuler_FoodDiary.AppForms
{
    public partial class CreateShopingListForm : Form
    {
        ShoppingList _shopingList;
        public CreateShopingListForm()
        {
            InitializeComponent();
            _shopingList = new ShoppingList();
            UserExperienceManager.SetTitle(this, "Новый список");
        }

        private void FillModelFields()
        {
            ShopOfLocation _shopOfLocation = new ShopOfLocation();

            _shopOfLocation.ShopId = (int)shopIdComboBox.SelectedValue;
            _shopOfLocation.LocationId = (int)locationIdComboBox.SelectedValue;

            var ShopOfLocationId = new ShopOfLocation();

            if ((ShopOfLocationId = Program.context.ShopOfLocation.FirstOrDefault(s => s.ShopId == _shopOfLocation.ShopId && s.LocationId == _shopOfLocation.LocationId)) == null)
            {
                Program.context.ShopOfLocation.Add(_shopOfLocation);
            }
            else
            {
                _shopingList.ShopOfLocationId = ShopOfLocationId.IdShopOfLocation;
            }

            string comment;
            if((comment = commentShoppingListTextBox.Text) != null)
            {
                _shopingList.CommentShoppingList = comment;
            }
            else
            {
                _shopingList.CommentShoppingList = null;
            }
            _shopingList.Date = dateDateTimePicker.Value;
            _shopingList.IsArchive = 0;
        }

        private void CreateShopingListForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.ShopOfLocation". При необходимости она может быть перемещена или удалена.
            this.shopOfLocationTableAdapter.Fill(this.foodDiaryDataSet.ShopOfLocation);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.Location". При необходимости она может быть перемещена или удалена.
            this.locationTableAdapter.Fill(this.foodDiaryDataSet.Location);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.Shop". При необходимости она может быть перемещена или удалена.
            this.shopTableAdapter.Fill(this.foodDiaryDataSet.Shop);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.ShoppingList". При необходимости она может быть перемещена или удалена.
            //this.shoppingListTableAdapter.Fill(this.foodDiaryDataSet.ShoppingList);

            dateDateTimePicker.Value = DateTime.Now;

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
            UserExperienceManager.CustomizeControls(splitContainer.Panel2.Controls);
        }

        private void SaveAttentionBackground_Click(object sender, EventArgs e)
        {
            FillModelFields();

            if (_shopingList.isNew())
            {
                Program.context.ShoppingList.Add(_shopingList);
            }


            DialogResult toBeSaved = MessageBox.Show("Сохранить?", "Запрос подтверждения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (toBeSaved == DialogResult.No)
            {
                return;
            }

            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
