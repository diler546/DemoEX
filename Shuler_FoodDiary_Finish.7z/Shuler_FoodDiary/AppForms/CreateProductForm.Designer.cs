﻿namespace Shuler_FoodDiary.AppForms
{
    partial class CreateProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label productIdLabel;
            System.Windows.Forms.Label quantityLabel;
            System.Windows.Forms.Label commentProductLabel;
            this.shopOfLocationTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShopOfLocationTableAdapter();
            this.shopTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShopTableAdapter();
            this.tableAdapterManager = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.TableAdapterManager();
            this.shoppingListTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShoppingListTableAdapter();
            this.shoppingListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.foodDiaryDataSet = new Shuler_FoodDiary.FoodDiaryDataSet();
            this.SaveAttentionBackground = new System.Windows.Forms.Button();
            this.shopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shopOfLocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.locationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.locationTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.LocationTableAdapter();
            this.shoppingListOfProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingListOfProductTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShoppingListOfProductTableAdapter();
            this.productIdComboBox = new System.Windows.Forms.ComboBox();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.commentProductTextBox = new System.Windows.Forms.TextBox();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ProductTableAdapter();
            productIdLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            commentProductLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodDiaryDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopOfLocationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListOfProductBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // shopOfLocationTableAdapter
            // 
            this.shopOfLocationTableAdapter.ClearBeforeFill = true;
            // 
            // shopTableAdapter
            // 
            this.shopTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LocationTableAdapter = null;
            this.tableAdapterManager.ProductTableAdapter = null;
            this.tableAdapterManager.PromoTableAdapter = null;
            this.tableAdapterManager.ShopOfLocationTableAdapter = null;
            this.tableAdapterManager.ShopOfProductTableAdapter = null;
            this.tableAdapterManager.ShoppingListOfProductTableAdapter = null;
            this.tableAdapterManager.ShoppingListTableAdapter = this.shoppingListTableAdapter;
            this.tableAdapterManager.ShopTableAdapter = this.shopTableAdapter;
            this.tableAdapterManager.UpdateOrder = Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WorkingTimeTableAdapter = null;
            // 
            // shoppingListTableAdapter
            // 
            this.shoppingListTableAdapter.ClearBeforeFill = true;
            // 
            // shoppingListBindingSource
            // 
            this.shoppingListBindingSource.DataMember = "ShoppingList";
            this.shoppingListBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // foodDiaryDataSet
            // 
            this.foodDiaryDataSet.DataSetName = "FoodDiaryDataSet";
            this.foodDiaryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SaveAttentionBackground
            // 
            this.SaveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SaveAttentionBackground.Location = new System.Drawing.Point(22, 204);
            this.SaveAttentionBackground.Name = "SaveAttentionBackground";
            this.SaveAttentionBackground.Size = new System.Drawing.Size(342, 57);
            this.SaveAttentionBackground.TabIndex = 6;
            this.SaveAttentionBackground.Text = "Сохранить";
            this.SaveAttentionBackground.UseVisualStyleBackColor = true;
            this.SaveAttentionBackground.Click += new System.EventHandler(this.SaveAttentionBackground_Click);
            // 
            // shopBindingSource
            // 
            this.shopBindingSource.DataMember = "Shop";
            this.shopBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // shopOfLocationBindingSource
            // 
            this.shopOfLocationBindingSource.DataMember = "ShopOfLocation";
            this.shopOfLocationBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // locationBindingSource
            // 
            this.locationBindingSource.DataMember = "Location";
            this.locationBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(86, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(80, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Новый список";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Shuler_FoodDiary.Properties.Resources.ООО_Лапша_и_шалости;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.AutoScroll = true;
            this.splitContainer.Panel2.Controls.Add(productIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.productIdComboBox);
            this.splitContainer.Panel2.Controls.Add(quantityLabel);
            this.splitContainer.Panel2.Controls.Add(this.quantityTextBox);
            this.splitContainer.Panel2.Controls.Add(commentProductLabel);
            this.splitContainer.Panel2.Controls.Add(this.commentProductTextBox);
            this.splitContainer.Panel2.Controls.Add(this.SaveAttentionBackground);
            this.splitContainer.Size = new System.Drawing.Size(381, 450);
            this.splitContainer.SplitterDistance = 89;
            this.splitContainer.TabIndex = 2;
            // 
            // locationTableAdapter
            // 
            this.locationTableAdapter.ClearBeforeFill = true;
            // 
            // shoppingListOfProductBindingSource
            // 
            this.shoppingListOfProductBindingSource.DataMember = "ShoppingListOfProduct";
            this.shoppingListOfProductBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // shoppingListOfProductTableAdapter
            // 
            this.shoppingListOfProductTableAdapter.ClearBeforeFill = true;
            // 
            // productIdLabel
            // 
            productIdLabel.AutoSize = true;
            productIdLabel.Location = new System.Drawing.Point(19, 115);
            productIdLabel.Name = "productIdLabel";
            productIdLabel.Size = new System.Drawing.Size(52, 13);
            productIdLabel.TabIndex = 6;
            productIdLabel.Text = "Продукт:";
            // 
            // productIdComboBox
            // 
            this.productIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.shoppingListOfProductBindingSource, "ProductId", true));
            this.productIdComboBox.DataSource = this.productBindingSource;
            this.productIdComboBox.DisplayMember = "NameProduct";
            this.productIdComboBox.FormattingEnabled = true;
            this.productIdComboBox.Location = new System.Drawing.Point(119, 112);
            this.productIdComboBox.Name = "productIdComboBox";
            this.productIdComboBox.Size = new System.Drawing.Size(245, 21);
            this.productIdComboBox.TabIndex = 7;
            this.productIdComboBox.ValueMember = "IdProduct";
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(19, 142);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(69, 13);
            quantityLabel.TabIndex = 8;
            quantityLabel.Text = "Количество:";
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shoppingListOfProductBindingSource, "Quantity", true));
            this.quantityTextBox.Location = new System.Drawing.Point(119, 139);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(245, 20);
            this.quantityTextBox.TabIndex = 9;
            // 
            // commentProductLabel
            // 
            commentProductLabel.AutoSize = true;
            commentProductLabel.Location = new System.Drawing.Point(19, 168);
            commentProductLabel.Name = "commentProductLabel";
            commentProductLabel.Size = new System.Drawing.Size(86, 13);
            commentProductLabel.TabIndex = 10;
            commentProductLabel.Text = "Комментрарий:";
            // 
            // commentProductTextBox
            // 
            this.commentProductTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shoppingListOfProductBindingSource, "CommentProduct", true));
            this.commentProductTextBox.Location = new System.Drawing.Point(119, 165);
            this.commentProductTextBox.Name = "commentProductTextBox";
            this.commentProductTextBox.Size = new System.Drawing.Size(245, 20);
            this.commentProductTextBox.TabIndex = 11;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // CreateProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 450);
            this.Controls.Add(this.splitContainer);
            this.Name = "CreateProductForm";
            this.Text = "CreateProductForm";
            this.Load += new System.EventHandler(this.CreateProductForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodDiaryDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopOfLocationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListOfProductBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private FoodDiaryDataSetTableAdapters.ShopOfLocationTableAdapter shopOfLocationTableAdapter;
        private FoodDiaryDataSetTableAdapters.ShopTableAdapter shopTableAdapter;
        private FoodDiaryDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private FoodDiaryDataSetTableAdapters.ShoppingListTableAdapter shoppingListTableAdapter;
        private System.Windows.Forms.BindingSource shoppingListBindingSource;
        private FoodDiaryDataSet foodDiaryDataSet;
        private System.Windows.Forms.Button SaveAttentionBackground;
        private System.Windows.Forms.BindingSource shopBindingSource;
        private System.Windows.Forms.BindingSource shopOfLocationBindingSource;
        private System.Windows.Forms.BindingSource locationBindingSource;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.SplitContainer splitContainer;
        private FoodDiaryDataSetTableAdapters.LocationTableAdapter locationTableAdapter;
        private System.Windows.Forms.BindingSource shoppingListOfProductBindingSource;
        private FoodDiaryDataSetTableAdapters.ShoppingListOfProductTableAdapter shoppingListOfProductTableAdapter;
        private System.Windows.Forms.ComboBox productIdComboBox;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.TextBox commentProductTextBox;
        private System.Windows.Forms.BindingSource productBindingSource;
        private FoodDiaryDataSetTableAdapters.ProductTableAdapter productTableAdapter;
    }
}