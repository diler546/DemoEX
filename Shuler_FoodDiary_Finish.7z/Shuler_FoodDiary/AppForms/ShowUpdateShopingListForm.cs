﻿using Shuler_FoodDiary.FoodDiaryDataSetTableAdapters;
using Shuler_FoodDiary.Models;
using Shuler_FoodDiary.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shuler_FoodDiary.AppForms
{
    public partial class ShowUpdateShopingListForm : Form
    {
        private ShoppingList _shoppingList;
        private int selectedShop;
        private int selectedLocation;
        private bool isInitializing = true;
        public ShowUpdateShopingListForm(ShoppingList shoppingList)
        {
            InitializeComponent();
            _shoppingList = shoppingList;
            UserExperienceManager.SetTitle(this, $"Список покупок от  \"{_shoppingList.Date}\"");         
        }

        private void ShowUpdateShopingListForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.Shop". При необходимости она может быть перемещена или удалена.
            this.shopTableAdapter.Fill(this.foodDiaryDataSet.Shop);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.Location". При необходимости она может быть перемещена или удалена.
            this.locationTableAdapter.Fill(this.foodDiaryDataSet.Location);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.ShopOfLocation". При необходимости она может быть перемещена или удалена.
            this.shopOfLocationTableAdapter.Fill(this.foodDiaryDataSet.ShopOfLocation);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.ShoppingList". При необходимости она может быть перемещена или удалена.
            this.shoppingListTableAdapter.Fill(this.foodDiaryDataSet.ShoppingList);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.ShopOfProduct". При необходимости она может быть перемещена или удалена.
            this.shopOfProductTableAdapter.Fill(this.foodDiaryDataSet.ShopOfProduct);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.Product". При необходимости она может быть перемещена или удалена.
            this.productTableAdapter.Fill(this.foodDiaryDataSet.Product);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.ShoppingListOfProduct". При необходимости она может быть перемещена или удалена.
            //this.shoppingListOfProductTableAdapter.Fill(this.foodDiaryDataSet.ShoppingListOfProduct);

            shopOfLocationBindingSource.DataSource = Program.context.ShopOfLocation.Where(s => s.IdShopOfLocation == _shoppingList.ShopOfLocationId).ToList();
            shoppingListBindingSource.DataSource = Program.context.ShoppingList.Where(s => s.IdShoppingList == _shoppingList.IdShoppingList).ToList();
            
            IsArchive();

            CreateUpdateDateGridView();

            var shopOfLocation = Program.context.ShopOfLocation.FirstOrDefault(s => s.IdShopOfLocation == _shoppingList.ShopOfLocationId);
            
            selectedShop = shopOfLocation.ShopId;
            selectedLocation = shopOfLocation.LocationId;

            shopIdComboBox.SelectedValue = shopOfLocation.ShopId;
            locationIdComboBox.SelectedValue = shopOfLocation.LocationId;

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);

            isInitializing = false;
        }

        private void CreateUpdateDateGridView()
        {
            var shopProducts = Program.context.ShopOfProduct.ToList();

            shoppingListOfProductBindingSource.DataSource = Program.context.ShoppingListOfProduct.Where(s => s.ShoppingListId == _shoppingList.IdShoppingList).ToList();

            var shopOfLocation = Program.context.ShopOfLocation.FirstOrDefault(s => s.IdShopOfLocation == _shoppingList.ShopOfLocationId);

            for (int i = 0; i < shoppingListOfProductDataGridView.Rows.Count; i++)
            {
                shoppingListOfProductDataGridView.Rows[i].Cells[0].Value = i + 1;

                var productCell = shoppingListOfProductDataGridView.Rows[i].Cells["ProductId"].Value;

                if (productCell != null && int.TryParse(productCell.ToString(), out int productId))
                {
                    // Проверяем, есть ли этот продукт в магазине
                    var productInShop = shopProducts.FirstOrDefault(p => p.ProductId == productId && p.ShopId == shopOfLocation.ShopId);

                    // Если продукт найден, устанавливаем "Есть" или "Нет"
                    shoppingListOfProductDataGridView.Rows[i].Cells["IsAvailable"].Value =
                        (productInShop != null && productInShop.IsAvailable == 1) ? "Есть" : "Нет";
                }
            }
        }

        private void IsArchive()
        {
            if (_shoppingList.IsArchive == 1)
            {
                NewProductAttentionBackground.Visible = false;
                shopIdComboBox.Enabled = false;
                locationIdComboBox.Enabled = false;
                commentShoppingListTextBox.Enabled = false;
                shoppingListOfProductDataGridView.Enabled = false;
            }
        }

        private void СhangeComboBox()
        {
            // Проверяем, существует ли уже такая пара "магазин-локация"
            var shopOfLocation = Program.context.ShopOfLocation
                .FirstOrDefault(s => s.ShopId == selectedShop && s.LocationId == selectedLocation);

            if (shopOfLocation == null)
            {
                // Если не существует — создаём и добавляем в базу
                shopOfLocation = new ShopOfLocation
                {
                    ShopId = selectedShop,
                    LocationId = selectedLocation
                };

                Program.context.ShopOfLocation.Add(shopOfLocation);
                Program.context.SaveChanges(); // Сохраняем, чтобы получить новый Id
            }

            // Устанавливаем связку магазинов в список покупок
            _shoppingList.ShopOfLocationId = shopOfLocation.IdShopOfLocation;

            // Сохраняем изменения в ShoppingList
            Program.context.SaveChanges();

            MessageBox.Show("Изменения сохранены в БД", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);

            MainForm mainForm = Application.OpenForms.OfType<MainForm>().FirstOrDefault();
            mainForm.RefreshShoppingList();
        }

        private void shopIdLabel_Click(object sender, EventArgs e)
        {

        }

        private void shoppingListOfProductDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void shoppingListOfProductDataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in shoppingListOfProductDataGridView.Rows)
            {
                if (row.IsNewRow) continue; // Пропускаем пустую строку

                int id = Convert.ToInt32(row.Cells["ProductId"].Value);
                var product = Program.context.ShoppingListOfProduct.FirstOrDefault(p => p.IdShoppingListOfProduct == id);

                if (product != null)
                {
                    product.Quantity = Convert.ToInt32(row.Cells["dataGridViewTextBoxColumn4"].Value);
                    product.CommentProduct = row.Cells["dataGridViewTextBoxColumn5"].Value?.ToString();
                    // Добавляй другие поля по необходимости
                }
            }
            CreateUpdateDateGridView();

            Program.context.SaveChanges();
            MessageBox.Show("Изменения сохранены в БД", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void commentShoppingListTextBox_Leave(object sender, EventArgs e)
        {
            _shoppingList.CommentShoppingList = commentShoppingListTextBox.Text;
            Program.context.SaveChanges();
            MessageBox.Show("Изменения сохранены в БД", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);

            MainForm mainForm = Application.OpenForms.OfType<MainForm>().FirstOrDefault();
            mainForm.RefreshShoppingList();
        }

        private void locationIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isInitializing) return;
            selectedLocation = (int)locationIdComboBox.SelectedValue;  
            СhangeComboBox();
            
        }

        private void shopIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isInitializing) return;
            selectedShop = (int)shopIdComboBox.SelectedValue;  
            СhangeComboBox();
            CreateUpdateDateGridView();
        }

        private void NewProductAttentionBackground_Click(object sender, EventArgs e)
        {
            CreateProductForm createProductForm = new CreateProductForm(_shoppingList);
            DialogResult ProductSaved = createProductForm.ShowDialog();

            if (ProductSaved == DialogResult.OK)
            {
                MainForm mainForm = Application.OpenForms.OfType<MainForm>().FirstOrDefault();
                mainForm.RefreshShoppingList();

                CreateUpdateDateGridView();
            }
        }
    }
}
