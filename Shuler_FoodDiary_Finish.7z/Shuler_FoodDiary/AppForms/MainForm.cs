﻿using Shuler_FoodDiary.AppForms;
using Shuler_FoodDiary.CustomControls;
using Shuler_FoodDiary.Models;
using Shuler_FoodDiary.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Shuler_FoodDiary
{
    public partial class MainForm : Form
    {
        string selectedShop = "Все";
        string selectedLocation = "Все";
        public MainForm()
        {  
            InitializeComponent();
            UserExperienceManager.SetTitle(this, "Списоки покупок");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            
            CheckIsArchive();
            ShowShoppingList();
            InitCombobox();
            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
        }

        private void CheckIsArchive()
        {
            List<ShoppingList> shoppingLists = new List<ShoppingList>();

            shoppingLists = Program.context.ShoppingList
                .Where(s => s.IsArchive == 0 && DbFunctions.TruncateTime(s.Date)< DbFunctions.TruncateTime(DateTime.Today))
                .ToList();

            foreach (ShoppingList shoppingList in shoppingLists)
            {
                shoppingList.IsArchive = 1;
            }

            if (shoppingLists.Count > 0)
            {
                Program.context.SaveChanges();
            }

        }

        private void InitCombobox()
        {
            List<Shop> shops = Program.context.Shop.OrderBy(s => s.NameShop).ToList();
            List<Location> location = Program.context.Location.OrderBy(s => s.NameLocation).ToList();

            comboBoxShop.Items.Add("Все");
            comboBoxLocation.Items.Add("Все");

            for (int i = 0; i < shops.Count; i++)
            {
                comboBoxShop.Items.Add(shops[i].NameShop);
            }

            for (int i = 0; i < location.Count; i++)
            {
                comboBoxLocation.Items.Add(location[i].NameLocation);
            }

            comboBoxShop.SelectedIndex = 0;
            comboBoxLocation.SelectedIndex = 0;
        }
        private void ShowShoppingList()
        {         
            List<ShoppingList> shoppingLists = new List<ShoppingList>();

            // Получаем ID локации (если не "Все")
            int? locationId = selectedLocation != "Все"
                ? Program.context.Location.FirstOrDefault(l => l.NameLocation == selectedLocation)?.IdLocation
                : null;

            // Получаем ID магазина (если не "Все")
            int? shopId = selectedShop != "Все"
                ? Program.context.Shop.FirstOrDefault(s => s.NameShop == selectedShop)?.IdShop
                : null;

            // Фильтруем ShopOfLocation по выбранной локации и/или магазину
            var shopOfLocationIds = Program.context.ShopOfLocation
                .Where(s => (locationId == null || s.LocationId == locationId) &&
                            (shopId == null || s.ShopId == shopId))
                .Select(s => s.IdShopOfLocation)
                .ToList();

            // Фильтруем ShoppingList
            shoppingLists = Program.context.ShoppingList
                .Where(s => shopOfLocationIds.Contains(s.ShopOfLocationId))
                .OrderByDescending(s => s.Date)
                .ToList();

            foreach (ShoppingList shoppingList in shoppingLists)
            {
                flowLayoutPanel.Controls.Add(new ShopingListUserControl(shoppingList));
            }
        }

        private void ClearShoppingList()
        {
            splitContainer.Panel2.Controls[0].Controls.Clear();
        }

        public void RefreshShoppingList()
        {
            ClearShoppingList();
            ShowShoppingList();
        }


        private void NewShopingListAttentionBackground_Click(object sender, EventArgs e)
        {
            CreateShopingListForm createShopingListForm = new CreateShopingListForm();
            DialogResult ShopingListSaved = createShopingListForm.ShowDialog();

            if (ShopingListSaved == DialogResult.OK)
            {
                RefreshShoppingList();
            }
        }

        private void comboBoxShop_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedShop = comboBoxShop.SelectedItem.ToString();
            RefreshShoppingList();
        }

        private void comboBoxLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedLocation = comboBoxLocation.SelectedItem.ToString();
            RefreshShoppingList();
        }
    }
}
