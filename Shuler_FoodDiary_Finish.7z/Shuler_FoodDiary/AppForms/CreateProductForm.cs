﻿using Shuler_FoodDiary.CustomControls;
using Shuler_FoodDiary.Models;
using Shuler_FoodDiary.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shuler_FoodDiary.AppForms
{
    public partial class CreateProductForm : Form
    {
        private ShoppingList _shoppingList;
        private ShoppingListOfProduct _shoppingListOfProduct;
        public CreateProductForm(ShoppingList shopingList)
        {
            InitializeComponent();
            _shoppingList = shopingList;
            _shoppingListOfProduct = new ShoppingListOfProduct();
            UserExperienceManager.SetTitle(this, "Новый продукт");
        }

        private void CreateProductForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.Product". При необходимости она может быть перемещена или удалена.
            this.productTableAdapter.Fill(this.foodDiaryDataSet.Product);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "foodDiaryDataSet.ShoppingListOfProduct". При необходимости она может быть перемещена или удалена.
            this.shoppingListOfProductTableAdapter.Fill(this.foodDiaryDataSet.ShoppingListOfProduct);

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
            UserExperienceManager.CustomizeControls(splitContainer.Panel2.Controls);
        }

        private void FillModelFields()
        {
            _shoppingListOfProduct.ProductId = (int)productIdComboBox.SelectedValue;
            _shoppingListOfProduct.Quantity = int.Parse(quantityTextBox.Text);
            _shoppingListOfProduct.ShoppingListId = _shoppingList.IdShoppingList;

            if (_shoppingListOfProduct.CommentProduct != null)
            {
                _shoppingListOfProduct.CommentProduct = commentProductTextBox.Text;
            }
            else
            {
                _shoppingListOfProduct.CommentProduct = null;
            }

           
        }

        /// <summary>
        /// PKGH
        /// Проверка введенной пользователем информации. Если допущена ошибка,
        /// сообщить, в каком поле это случилось, и что можно вводить.
        /// </summary>
        /// <param name="pattern">Паттерн</param>
        /// <param name="userInputText">Текст, введенный пользователем в поле на форме.</param>
        /// <param name="field">Поле, в котором пользователь допустил ошибку.</param>
        /// <param name="messageAboutAllowedSymbols">Какие символы разрешено вводить в это поле.</param>
        /// <exception cref="ValidationException"></exception>
        private void ValidateGeneral(string userInputText, string field, string messageAboutAllowedSymbols = "поле не должно быть пустым.", string pattern = @"^.+$")
        {
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
            bool isValid = regex.IsMatch(userInputText.Trim());
            if (!isValid)
            {
                throw new ValidationException($"{field}: {messageAboutAllowedSymbols}");
            }
        }

        private void ValidateProduct()
        {
            var productId = new ShoppingListOfProduct();
            var product = new Product();
            if ((productId = Program.context.ShoppingListOfProduct.FirstOrDefault(s => s.ProductId == (int)productIdComboBox.SelectedValue && s.ShoppingListId ==_shoppingList.IdShoppingList)) != null)
            {
               product = Program.context.Product.FirstOrDefault(p =>p.IdProduct == productId.ProductId);
               throw new ValidationException($"Продукт: {product.NameProduct} уже присутствует в списке");
            }
        }

        private void Validate()
        {
            ValidateQuantity();
            ValidateProduct();
        }

        private void ValidateQuantity()
        {
            ValidateGeneral(quantityTextBox.Text, "Количество", "допустимо только целое неотрицательное число.", @"^[1-9][0-9]*$");
        }

        private void SaveAttentionBackground_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            FillModelFields();

            Program.context.ShoppingListOfProduct.Add(_shoppingListOfProduct);

            DialogResult toBeSaved = MessageBox.Show("Сохранить?", "Запрос  подтверждения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (toBeSaved == DialogResult.No)
            {
                return;
            }

            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
