﻿namespace Shuler_FoodDiary
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.NewShopingListAttentionBackground = new System.Windows.Forms.Button();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.comboBoxLocation = new System.Windows.Forms.ComboBox();
            this.comboBoxShop = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.filterShopLabelAttentionFont = new System.Windows.Forms.Label();
            this.filterLocationLabelAttentionFont = new System.Windows.Forms.Label();
            this.filterLabelAttentionFont = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.AutoScroll = true;
            this.flowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Padding = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.flowLayoutPanel.Size = new System.Drawing.Size(800, 356);
            this.flowLayoutPanel.TabIndex = 0;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(86, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(88, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Списки покупок";
            // 
            // NewShopingListAttentionBackground
            // 
            this.NewShopingListAttentionBackground.Location = new System.Drawing.Point(89, 46);
            this.NewShopingListAttentionBackground.Name = "NewShopingListAttentionBackground";
            this.NewShopingListAttentionBackground.Size = new System.Drawing.Size(96, 23);
            this.NewShopingListAttentionBackground.TabIndex = 2;
            this.NewShopingListAttentionBackground.Text = "Новый список";
            this.NewShopingListAttentionBackground.UseVisualStyleBackColor = true;
            this.NewShopingListAttentionBackground.Click += new System.EventHandler(this.NewShopingListAttentionBackground_Click);
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.filterLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.filterLocationLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.filterShopLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.comboBoxLocation);
            this.splitContainer.Panel1.Controls.Add(this.comboBoxShop);
            this.splitContainer.Panel1.Controls.Add(this.NewShopingListAttentionBackground);
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.flowLayoutPanel);
            this.splitContainer.Size = new System.Drawing.Size(800, 450);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 0;
            // 
            // comboBoxLocation
            // 
            this.comboBoxLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxLocation.FormattingEnabled = true;
            this.comboBoxLocation.Location = new System.Drawing.Point(636, 47);
            this.comboBoxLocation.Name = "comboBoxLocation";
            this.comboBoxLocation.Size = new System.Drawing.Size(121, 21);
            this.comboBoxLocation.TabIndex = 4;
            this.comboBoxLocation.SelectedIndexChanged += new System.EventHandler(this.comboBoxLocation_SelectedIndexChanged);
            // 
            // comboBoxShop
            // 
            this.comboBoxShop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxShop.FormattingEnabled = true;
            this.comboBoxShop.Location = new System.Drawing.Point(483, 48);
            this.comboBoxShop.Name = "comboBoxShop";
            this.comboBoxShop.Size = new System.Drawing.Size(121, 21);
            this.comboBoxShop.TabIndex = 3;
            this.comboBoxShop.SelectedIndexChanged += new System.EventHandler(this.comboBoxShop_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Shuler_FoodDiary.Properties.Resources.ООО_Лапша_и_шалости;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // filterShopLabelAttentionFont
            // 
            this.filterShopLabelAttentionFont.AutoSize = true;
            this.filterShopLabelAttentionFont.Location = new System.Drawing.Point(501, 32);
            this.filterShopLabelAttentionFont.Name = "filterShopLabelAttentionFont";
            this.filterShopLabelAttentionFont.Size = new System.Drawing.Size(70, 13);
            this.filterShopLabelAttentionFont.TabIndex = 5;
            this.filterShopLabelAttentionFont.Text = "по магазину";
            // 
            // filterLocationLabelAttentionFont
            // 
            this.filterLocationLabelAttentionFont.AutoSize = true;
            this.filterLocationLabelAttentionFont.Location = new System.Drawing.Point(671, 32);
            this.filterLocationLabelAttentionFont.Name = "filterLocationLabelAttentionFont";
            this.filterLocationLabelAttentionFont.Size = new System.Drawing.Size(52, 13);
            this.filterLocationLabelAttentionFont.TabIndex = 6;
            this.filterLocationLabelAttentionFont.Text = "по месту";
            // 
            // filterLabelAttentionFont
            // 
            this.filterLabelAttentionFont.AutoSize = true;
            this.filterLabelAttentionFont.Location = new System.Drawing.Point(588, 9);
            this.filterLabelAttentionFont.Name = "filterLabelAttentionFont";
            this.filterLabelAttentionFont.Size = new System.Drawing.Size(71, 13);
            this.filterLabelAttentionFont.TabIndex = 7;
            this.filterLabelAttentionFont.Text = "Фильтрация";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer);
            this.MinimumSize = new System.Drawing.Size(816, 485);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.Button NewShopingListAttentionBackground;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.ComboBox comboBoxLocation;
        private System.Windows.Forms.ComboBox comboBoxShop;
        private System.Windows.Forms.Label filterLocationLabelAttentionFont;
        private System.Windows.Forms.Label filterShopLabelAttentionFont;
        private System.Windows.Forms.Label filterLabelAttentionFont;
    }
}

