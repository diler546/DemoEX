﻿namespace Shuler_FoodDiary.AppForms
{
    partial class CreateShopingListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dateLabel;
            System.Windows.Forms.Label commentShoppingListLabel;
            System.Windows.Forms.Label shopIdLabel;
            System.Windows.Forms.Label locationIdLabel;
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.locationIdComboBox = new System.Windows.Forms.ComboBox();
            this.shopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.foodDiaryDataSet = new Shuler_FoodDiary.FoodDiaryDataSet();
            this.locationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shopIdComboBox = new System.Windows.Forms.ComboBox();
            this.shoppingListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SaveAttentionBackground = new System.Windows.Forms.Button();
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.commentShoppingListTextBox = new System.Windows.Forms.TextBox();
            this.shoppingListTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShoppingListTableAdapter();
            this.tableAdapterManager = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.TableAdapterManager();
            this.shopTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShopTableAdapter();
            this.locationTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.LocationTableAdapter();
            this.shopOfLocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shopOfLocationTableAdapter = new Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.ShopOfLocationTableAdapter();
            dateLabel = new System.Windows.Forms.Label();
            commentShoppingListLabel = new System.Windows.Forms.Label();
            shopIdLabel = new System.Windows.Forms.Label();
            locationIdLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodDiaryDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopOfLocationBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dateLabel
            // 
            dateLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            dateLabel.AutoSize = true;
            dateLabel.Location = new System.Drawing.Point(31, 77);
            dateLabel.Name = "dateLabel";
            dateLabel.Size = new System.Drawing.Size(36, 13);
            dateLabel.TabIndex = 0;
            dateLabel.Text = "Дата:";
            // 
            // commentShoppingListLabel
            // 
            commentShoppingListLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            commentShoppingListLabel.AutoSize = true;
            commentShoppingListLabel.Location = new System.Drawing.Point(30, 156);
            commentShoppingListLabel.Name = "commentShoppingListLabel";
            commentShoppingListLabel.Size = new System.Drawing.Size(140, 13);
            commentShoppingListLabel.TabIndex = 4;
            commentShoppingListLabel.Text = "Комментарий для списка:";
            // 
            // shopIdLabel
            // 
            shopIdLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            shopIdLabel.AutoSize = true;
            shopIdLabel.Location = new System.Drawing.Point(31, 105);
            shopIdLabel.Name = "shopIdLabel";
            shopIdLabel.Size = new System.Drawing.Size(54, 13);
            shopIdLabel.TabIndex = 7;
            shopIdLabel.Text = "Магазин:";
            // 
            // locationIdLabel
            // 
            locationIdLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            locationIdLabel.AutoSize = true;
            locationIdLabel.Location = new System.Drawing.Point(30, 132);
            locationIdLabel.Name = "locationIdLabel";
            locationIdLabel.Size = new System.Drawing.Size(54, 13);
            locationIdLabel.TabIndex = 8;
            locationIdLabel.Text = "Локация:";
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.AutoScroll = true;
            this.splitContainer.Panel2.Controls.Add(locationIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.locationIdComboBox);
            this.splitContainer.Panel2.Controls.Add(shopIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.shopIdComboBox);
            this.splitContainer.Panel2.Controls.Add(this.SaveAttentionBackground);
            this.splitContainer.Panel2.Controls.Add(dateLabel);
            this.splitContainer.Panel2.Controls.Add(this.dateDateTimePicker);
            this.splitContainer.Panel2.Controls.Add(commentShoppingListLabel);
            this.splitContainer.Panel2.Controls.Add(this.commentShoppingListTextBox);
            this.splitContainer.Size = new System.Drawing.Size(403, 414);
            this.splitContainer.SplitterDistance = 82;
            this.splitContainer.TabIndex = 1;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(86, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(80, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Новый список";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Shuler_FoodDiary.Properties.Resources.ООО_Лапша_и_шалости;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // locationIdComboBox
            // 
            this.locationIdComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.locationIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.shopOfLocationBindingSource, "LocationId", true));
            this.locationIdComboBox.DataSource = this.locationBindingSource;
            this.locationIdComboBox.DisplayMember = "NameLocation";
            this.locationIdComboBox.FormattingEnabled = true;
            this.locationIdComboBox.Location = new System.Drawing.Point(175, 124);
            this.locationIdComboBox.Name = "locationIdComboBox";
            this.locationIdComboBox.Size = new System.Drawing.Size(200, 21);
            this.locationIdComboBox.TabIndex = 9;
            this.locationIdComboBox.ValueMember = "IdLocation";
            // 
            // shopBindingSource
            // 
            this.shopBindingSource.DataMember = "Shop";
            this.shopBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // foodDiaryDataSet
            // 
            this.foodDiaryDataSet.DataSetName = "FoodDiaryDataSet";
            this.foodDiaryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // locationBindingSource
            // 
            this.locationBindingSource.DataMember = "Location";
            this.locationBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // shopIdComboBox
            // 
            this.shopIdComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.shopIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.shopOfLocationBindingSource, "ShopId", true));
            this.shopIdComboBox.DataSource = this.shopBindingSource;
            this.shopIdComboBox.DisplayMember = "NameShop";
            this.shopIdComboBox.FormattingEnabled = true;
            this.shopIdComboBox.Location = new System.Drawing.Point(175, 97);
            this.shopIdComboBox.Name = "shopIdComboBox";
            this.shopIdComboBox.Size = new System.Drawing.Size(200, 21);
            this.shopIdComboBox.TabIndex = 8;
            this.shopIdComboBox.ValueMember = "IdShop";
            // 
            // shoppingListBindingSource
            // 
            this.shoppingListBindingSource.DataMember = "ShoppingList";
            this.shoppingListBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // SaveAttentionBackground
            // 
            this.SaveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SaveAttentionBackground.Location = new System.Drawing.Point(33, 190);
            this.SaveAttentionBackground.Name = "SaveAttentionBackground";
            this.SaveAttentionBackground.Size = new System.Drawing.Size(342, 57);
            this.SaveAttentionBackground.TabIndex = 6;
            this.SaveAttentionBackground.Text = "Сохранить";
            this.SaveAttentionBackground.UseVisualStyleBackColor = true;
            this.SaveAttentionBackground.Click += new System.EventHandler(this.SaveAttentionBackground_Click);
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.shoppingListBindingSource, "Date", true));
            this.dateDateTimePicker.Enabled = false;
            this.dateDateTimePicker.Location = new System.Drawing.Point(175, 71);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateDateTimePicker.TabIndex = 1;
            // 
            // commentShoppingListTextBox
            // 
            this.commentShoppingListTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.commentShoppingListTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shoppingListBindingSource, "CommentShoppingList", true));
            this.commentShoppingListTextBox.Location = new System.Drawing.Point(175, 153);
            this.commentShoppingListTextBox.Name = "commentShoppingListTextBox";
            this.commentShoppingListTextBox.Size = new System.Drawing.Size(200, 20);
            this.commentShoppingListTextBox.TabIndex = 5;
            // 
            // shoppingListTableAdapter
            // 
            this.shoppingListTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LocationTableAdapter = null;
            this.tableAdapterManager.ProductTableAdapter = null;
            this.tableAdapterManager.PromoTableAdapter = null;
            this.tableAdapterManager.ShopOfLocationTableAdapter = null;
            this.tableAdapterManager.ShopOfProductTableAdapter = null;
            this.tableAdapterManager.ShoppingListOfProductTableAdapter = null;
            this.tableAdapterManager.ShoppingListTableAdapter = this.shoppingListTableAdapter;
            this.tableAdapterManager.ShopTableAdapter = this.shopTableAdapter;
            this.tableAdapterManager.UpdateOrder = Shuler_FoodDiary.FoodDiaryDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WorkingTimeTableAdapter = null;
            // 
            // shopTableAdapter
            // 
            this.shopTableAdapter.ClearBeforeFill = true;
            // 
            // locationTableAdapter
            // 
            this.locationTableAdapter.ClearBeforeFill = true;
            // 
            // shopOfLocationBindingSource
            // 
            this.shopOfLocationBindingSource.DataMember = "ShopOfLocation";
            this.shopOfLocationBindingSource.DataSource = this.foodDiaryDataSet;
            // 
            // shopOfLocationTableAdapter
            // 
            this.shopOfLocationTableAdapter.ClearBeforeFill = true;
            // 
            // CreateShopingListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 414);
            this.Controls.Add(this.splitContainer);
            this.Name = "CreateShopingListForm";
            this.Text = "CreateShopingListForm";
            this.Load += new System.EventHandler(this.CreateShopingListForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodDiaryDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopOfLocationBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private FoodDiaryDataSet foodDiaryDataSet;
        private System.Windows.Forms.BindingSource shoppingListBindingSource;
        private FoodDiaryDataSetTableAdapters.ShoppingListTableAdapter shoppingListTableAdapter;
        private FoodDiaryDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox shopIdComboBox;
        private System.Windows.Forms.Button SaveAttentionBackground;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.TextBox commentShoppingListTextBox;
        private FoodDiaryDataSetTableAdapters.ShopTableAdapter shopTableAdapter;
        private System.Windows.Forms.BindingSource shopBindingSource;
        private System.Windows.Forms.ComboBox locationIdComboBox;
        private System.Windows.Forms.BindingSource locationBindingSource;
        private FoodDiaryDataSetTableAdapters.LocationTableAdapter locationTableAdapter;
        private System.Windows.Forms.BindingSource shopOfLocationBindingSource;
        private FoodDiaryDataSetTableAdapters.ShopOfLocationTableAdapter shopOfLocationTableAdapter;
    }
}