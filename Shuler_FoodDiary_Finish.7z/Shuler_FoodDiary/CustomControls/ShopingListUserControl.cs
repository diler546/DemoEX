﻿using Shuler_FoodDiary.AppForms;
using Shuler_FoodDiary.Models;
using Shuler_FoodDiary.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shuler_FoodDiary.CustomControls
{
    public partial class ShopingListUserControl : UserControl
    {

        private ShoppingList _shoppingList;
        public ShopingListUserControl(ShoppingList shoppingList)
        {
            InitializeComponent();
            _shoppingList = shoppingList;
            SetLabeTextlValues();
        }

        private void SetLabeTextlValues()
        {
            var shopOfLocation = Program.context.ShopOfLocation.FirstOrDefault(s => s.IdShopOfLocation == _shoppingList.ShopOfLocationId);

            var shop = Program.context.Shop.FirstOrDefault(s => s.IdShop == shopOfLocation.ShopId).IdShop;

            var working = Program.context.Shop.FirstOrDefault(s => s.IdShop == shopOfLocation.ShopId).WorkingTimeId;

            var work = Program.context.WorkingTime.Where(w => w.IdWorkingTime == working).ToList();

            TimeSpan timeSpan = new TimeSpan(0,0,0);
            if ((work[0].OpeningWorkWeek == timeSpan && work[0].ClosingWorkWeek == timeSpan) && (work[0].OpeningWeekends == timeSpan && work[0].ClosingWeekends == timeSpan)) 
            {
                workingTimeLabel.Text = "(круглосуточно)";
            }
            else if ((work[0].OpeningWorkWeek == work[0].OpeningWeekends && work[0].ClosingWorkWeek == work[0].ClosingWeekends))
            {
                 workingTimeLabel.Text = $"({work[0].OpeningWorkWeek}-{work[0].ClosingWorkWeek})";
            }
            else
            {
                workingTimeLabel.Text = $"({work[0].OpeningWorkWeek}-{work[0].ClosingWorkWeek},{work[0].OpeningWeekends}-{work[0].ClosingWeekends})";
            }
            

            shopLabel.Text = Program.context.Shop.FirstOrDefault(s => s.IdShop == shopOfLocation.ShopId).NameShop;
            DateLabel.Text = _shoppingList.Date.ToString();
            locationLabel.Text = Program.context.Location.FirstOrDefault(s => s.IdLocation == shopOfLocation.LocationId).NameLocation;
            string comment;
            if ((comment = _shoppingList.CommentShoppingList) != null)
            {
                commentShoppingListLabel.Text = comment;
            }
            else
            {
                commentShoppingListLabel.Text = "Комментарий отсутствует";
            }
            var promo = Program.context.Promo.FirstOrDefault(s => s.ShopId == shop);
            if((promo) != null)
            {
                PromoLabel.Text = promo.NamePromo;
            }
            else
            {
                PromoLabel.Text = "Промокод отсутствует";
            }
            ListItemsLabel.Text = $"Позиций в списке: {_shoppingList.ItemsCount}";
            InWorkLabel.Text = "В работе";
        }

        private void ShopingListUserControl_Click(object sender, EventArgs e)
        {
            ShowUpdateShopingListForm showUpdateShopingListForm = new ShowUpdateShopingListForm(_shoppingList);
            DialogResult ShopingListSaved = showUpdateShopingListForm.ShowDialog();
        }

        private void ShopingListUserControl_Paint(object sender, PaintEventArgs e)
        {
            if (_shoppingList.IsArchive == 1)
            {
                ControlPaint.DrawBorder(e.Graphics, ClientRectangle,
                Color.Black, ButtonBorderStyle.Solid);
            }
            else
            {
                ControlPaint.DrawBorder(e.Graphics, ClientRectangle,
                ColorTranslator.FromHtml(Constants.Color.attentionColor), ButtonBorderStyle.Solid);
            }    
        }

        private void IsArchive()
        {
            if (_shoppingList.IsArchive == 1)
            {
                archiveAttentionBackground.Visible = false;
                InWorkLabel.Visible = false;
                this.BackColor = Color.Gray;
            }
        }

        private void ShopingListUserControl_Load(object sender, EventArgs e)
        {
            IsArchive();
            UserExperienceManager.CustomizeControls(this.Controls);
        }

        private void archiveAttentionBackground_Click(object sender, EventArgs e)
        {
            _shoppingList.IsArchive = 1;
        }
    }
}
