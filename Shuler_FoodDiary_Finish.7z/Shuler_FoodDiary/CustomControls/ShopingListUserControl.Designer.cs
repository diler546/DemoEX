﻿namespace Shuler_FoodDiary.CustomControls
{
    partial class ShopingListUserControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.shopLabel = new System.Windows.Forms.Label();
            this.workingTimeLabel = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.locationLabel = new System.Windows.Forms.Label();
            this.commentShoppingListLabel = new System.Windows.Forms.Label();
            this.PromoLabel = new System.Windows.Forms.Label();
            this.ListItemsLabel = new System.Windows.Forms.Label();
            this.archiveAttentionBackground = new System.Windows.Forms.Button();
            this.InWorkLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // shopLabel
            // 
            this.shopLabel.AutoSize = true;
            this.shopLabel.Location = new System.Drawing.Point(13, 17);
            this.shopLabel.Name = "shopLabel";
            this.shopLabel.Size = new System.Drawing.Size(32, 13);
            this.shopLabel.TabIndex = 0;
            this.shopLabel.Text = "Shop";
            this.shopLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // workingTimeLabel
            // 
            this.workingTimeLabel.AutoSize = true;
            this.workingTimeLabel.Location = new System.Drawing.Point(13, 41);
            this.workingTimeLabel.Name = "workingTimeLabel";
            this.workingTimeLabel.Size = new System.Drawing.Size(70, 13);
            this.workingTimeLabel.TabIndex = 1;
            this.workingTimeLabel.Text = "WorkingTime";
            this.workingTimeLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // DateLabel
            // 
            this.DateLabel.AutoSize = true;
            this.DateLabel.Location = new System.Drawing.Point(13, 94);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(30, 13);
            this.DateLabel.TabIndex = 2;
            this.DateLabel.Text = "Date";
            this.DateLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(13, 119);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(48, 13);
            this.locationLabel.TabIndex = 3;
            this.locationLabel.Text = "Location";
            this.locationLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // commentShoppingListLabel
            // 
            this.commentShoppingListLabel.AutoSize = true;
            this.commentShoppingListLabel.Location = new System.Drawing.Point(265, 17);
            this.commentShoppingListLabel.Name = "commentShoppingListLabel";
            this.commentShoppingListLabel.Size = new System.Drawing.Size(112, 13);
            this.commentShoppingListLabel.TabIndex = 4;
            this.commentShoppingListLabel.Text = "CommentShoppingList";
            this.commentShoppingListLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // PromoLabel
            // 
            this.PromoLabel.AutoSize = true;
            this.PromoLabel.Location = new System.Drawing.Point(265, 65);
            this.PromoLabel.Name = "PromoLabel";
            this.PromoLabel.Size = new System.Drawing.Size(37, 13);
            this.PromoLabel.TabIndex = 5;
            this.PromoLabel.Text = "Promo";
            this.PromoLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // ListItemsLabel
            // 
            this.ListItemsLabel.AutoSize = true;
            this.ListItemsLabel.Location = new System.Drawing.Point(608, 17);
            this.ListItemsLabel.Name = "ListItemsLabel";
            this.ListItemsLabel.Size = new System.Drawing.Size(48, 13);
            this.ListItemsLabel.TabIndex = 6;
            this.ListItemsLabel.Text = "ListItems";
            this.ListItemsLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // archiveAttentionBackground
            // 
            this.archiveAttentionBackground.Location = new System.Drawing.Point(611, 84);
            this.archiveAttentionBackground.Name = "archiveAttentionBackground";
            this.archiveAttentionBackground.Size = new System.Drawing.Size(96, 23);
            this.archiveAttentionBackground.TabIndex = 7;
            this.archiveAttentionBackground.Text = "Архивировать";
            this.archiveAttentionBackground.UseVisualStyleBackColor = true;
            this.archiveAttentionBackground.Click += new System.EventHandler(this.archiveAttentionBackground_Click);
            // 
            // InWorkLabel
            // 
            this.InWorkLabel.AutoSize = true;
            this.InWorkLabel.Location = new System.Drawing.Point(608, 119);
            this.InWorkLabel.Name = "InWorkLabel";
            this.InWorkLabel.Size = new System.Drawing.Size(42, 13);
            this.InWorkLabel.TabIndex = 8;
            this.InWorkLabel.Text = "InWork";
            this.InWorkLabel.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            // 
            // ShopingListUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(232)))), ((int)(((byte)(211)))));
            this.Controls.Add(this.InWorkLabel);
            this.Controls.Add(this.archiveAttentionBackground);
            this.Controls.Add(this.ListItemsLabel);
            this.Controls.Add(this.PromoLabel);
            this.Controls.Add(this.commentShoppingListLabel);
            this.Controls.Add(this.locationLabel);
            this.Controls.Add(this.DateLabel);
            this.Controls.Add(this.workingTimeLabel);
            this.Controls.Add(this.shopLabel);
            this.Name = "ShopingListUserControl";
            this.Size = new System.Drawing.Size(740, 150);
            this.Load += new System.EventHandler(this.ShopingListUserControl_Load);
            this.Click += new System.EventHandler(this.ShopingListUserControl_Click);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ShopingListUserControl_Paint);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label shopLabel;
        private System.Windows.Forms.Label workingTimeLabel;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Label commentShoppingListLabel;
        private System.Windows.Forms.Label PromoLabel;
        private System.Windows.Forms.Label ListItemsLabel;
        private System.Windows.Forms.Button archiveAttentionBackground;
        private System.Windows.Forms.Label InWorkLabel;
    }
}
